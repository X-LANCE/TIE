#!bin/bash

python dataset_generation.py --root_dir data/ --version websrc1.0
python data_preprocess.py --root_dir data/ --task rect_mask --percentage 0.5
