#!bin/bash

mask=0
python -u -W ignore run.py                     \
  --train_file data/websrc1.0_train_.json      \
  --predict_file data/websrc1.0_dev_.json      \
  --model_type bert --loss_method MSE          \
  --model_name_or_path bert-base-uncased       \
  --output_dir result/MSE_${mask}/             \
  --do_lower_case --do_train --do_eval         \
  --mask_method ${mask} --resume_from_PLM QA/HPLM
