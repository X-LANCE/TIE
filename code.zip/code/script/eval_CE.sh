#!bin/bash

mask=0
python -u -W ignore run.py                 \
  --train_file data/websrc1.0_train_.json  \
  --predict_file data/websrc1.0_dev_.json  \
  --model_type bert --loss_method CE       \
  --model_name_or_path bert-base-uncased   \
  --output_dir result/CE_${mask}/          \
  --do_lower_case --mask_method ${mask}    \
  --per_gpu_eval_batch_size 64             \
  --do_eval --eval_all_checkpoints
